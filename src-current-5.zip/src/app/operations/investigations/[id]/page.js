import { notFound } from "next/navigation";

import AppLayout from "../../../../components/layout/AppLayout";
import WorkspaceHeader from "../../../../components/ui/WorkspaceHeader";

import Situation from "../../../../components/workspace/Situation";
import SyntrixAssessment from "../../../../components/workspace/SyntrixAssessment";
import ExecutionPlaybook from "../../../../components/workspace/ExecutionPlaybook";
import CaseHistory from "../../../../components/workspace/CaseHistory";

import {
  getInvestigationWorkspace,
} from "../../../../lib/services/getInvestigationWorkspace";
import {
  getRequestContext,
} from "../../../../lib/auth/getRequestContext";

export default async function InvestigationPage({
  params,
}) {
  const { id } = await params;

  const requestContext =
    await getRequestContext();

  const workspace =
    getInvestigationWorkspace(
      requestContext,
      id,
    );

  if (!workspace) {
    notFound();
  }

  const {
    situation,
    assessment,
    execution,
    history,
  } = workspace;

  return (
    <AppLayout>
      <section className="mx-auto max-w-7xl">
        <WorkspaceHeader
          eyebrow="Investigation"
          title={situation.priority.title}
          description={
            situation.priority.whyNow ??
            situation.signal?.description ??
            "Review Syntrix’s assessment and recommended response."
          }
        />

        <div className="mt-8 space-y-8">
          <Situation
            situation={situation}
          />

          <SyntrixAssessment
            assessment={assessment}
          />

          <ExecutionPlaybook
            execution={execution}
          />

          <CaseHistory
            history={history}
          />
        </div>
      </section>
    </AppLayout>
  );
}